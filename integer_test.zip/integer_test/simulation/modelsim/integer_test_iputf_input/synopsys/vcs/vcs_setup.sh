cp -f C:/projects/Quartus/fft_test/integer_test/fft/fft/simulation/submodules/fft_fft_ii_0_opt_twi1.hex ./
cp -f C:/projects/Quartus/fft_test/integer_test/fft/fft/simulation/submodules/fft_fft_ii_0_opt_twr1.hex ./
cp -f C:/projects/Quartus/fft_test/integer_test/fft/fft/simulation/submodules/fft_fft_ii_0_opt_twi2.hex ./
cp -f C:/projects/Quartus/fft_test/integer_test/fft/fft/simulation/submodules/fft_fft_ii_0_opt_twr2.hex ./
