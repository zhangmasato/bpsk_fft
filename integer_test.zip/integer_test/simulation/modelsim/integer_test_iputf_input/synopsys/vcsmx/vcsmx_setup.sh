
cp -f C:/projects/Quartus/fft_test/integer_test/fft/fft/simulation/submodules/fft_fft_ii_0_opt_twi1.hex ./
cp -f C:/projects/Quartus/fft_test/integer_test/fft/fft/simulation/submodules/fft_fft_ii_0_opt_twr1.hex ./
cp -f C:/projects/Quartus/fft_test/integer_test/fft/fft/simulation/submodules/fft_fft_ii_0_opt_twi2.hex ./
cp -f C:/projects/Quartus/fft_test/integer_test/fft/fft/simulation/submodules/fft_fft_ii_0_opt_twr2.hex ./

vhdlan -xlrm          "C:/projects/Quartus/fft_test/integer_test/fft/fft/simulation/submodules/auk_dspip_text_pkg.vhd" -work fft_ii_0
vhdlan -xlrm          "C:/projects/Quartus/fft_test/integer_test/fft/fft/simulation/submodules/auk_dspip_math_pkg.vhd" -work fft_ii_0
vhdlan -xlrm          "C:/projects/Quartus/fft_test/integer_test/fft/fft/simulation/submodules/auk_dspip_lib_pkg.vhd"  -work fft_ii_0
vhdlan -xlrm          "C:/projects/Quartus/fft_test/integer_test/fft/fft/simulation/submodules/auk_dspip_roundsat.vhd" -work fft_ii_0
vlogan +v2k -sverilog "C:/projects/Quartus/fft_test/integer_test/fft/fft/simulation/submodules/fft_fft_ii_0.sv"        -work fft_ii_0
vlogan +v2k           "C:/projects/Quartus/fft_test/integer_test/fft/fft/simulation/fft.v"                                           
